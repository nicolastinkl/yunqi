//
//  ChatUserCell.h
//  ISClone
//
//  Created by Molon on 13-12-2.
//  Copyright (c) 2013年 Molon. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Chat;
@interface ChatUserCell : UITableViewCell

@property (strong, nonatomic) Chat *chat;

@end
