//
//  ConverReply.m
//  laixin
//
//  Created by apple on 14-1-11.
//  Copyright (c) 2014年 jijia. All rights reserved.
//

#import "ConverReply.h"
#import "FCReplyMessage.h"


@implementation ConverReply

@dynamic badgeNumber;
@dynamic time;
@dynamic uid;
@dynamic postid;
@dynamic content;
@dynamic fcreplymesgships;

@end
