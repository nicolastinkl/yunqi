//
//  FCUserDescription.m
//  laixin
//
//  Created by apple on 13-12-27.
//  Copyright (c) 2013年 jijia. All rights reserved.
//

#import "FCUserDescription.h"
#import "FCAccount.h"
#import "FCFriends.h"


@implementation FCUserDescription
@dynamic background_image;
@dynamic birthday;
@dynamic create_time;
@dynamic headpic;
@dynamic height;
@dynamic marriage;
@dynamic nick;
@dynamic sex;
@dynamic signature;
@dynamic uid;
@dynamic userDesp;
@dynamic userDespFriends;
@dynamic active_by,active_level,actor,actor_level,position,nick_pinyin,nick_frist_pinyin;
@end
