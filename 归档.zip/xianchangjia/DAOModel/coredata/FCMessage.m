//
//  FCMessage.m
//  laixin
//
//  Created by apple on 13-12-31.
//  Copyright (c) 2013年 jijia. All rights reserved.
//

#import "FCMessage.h"
#import "Conversation.h"
#import "FCUserDescription.h"


@implementation FCMessage

@dynamic messageStatus;
@dynamic read;
@dynamic sentDate;
@dynamic text;
@dynamic messageType;
@dynamic imageUrl;
@dynamic conversation;
@dynamic messageUser;
@dynamic messageId;
@dynamic latitude,longitude,audioUrl,videoUrl,messageguid,messageSendStatus,audioLength,wechatid;
@end
