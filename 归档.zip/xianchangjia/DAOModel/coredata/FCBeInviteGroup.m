//
//  FCBeInviteGroup.m
//  laixin
//
//  Created by apple on 14-1-10.
//  Copyright (c) 2014年 jijia. All rights reserved.
//

#import "FCBeInviteGroup.h"
#import "FCHomeGroupMsg.h"
#import "FCUserDescription.h"


@implementation FCBeInviteGroup

@dynamic beaddTime;
@dynamic groupID;
@dynamic groupJson;
@dynamic groupName;
@dynamic eid;
@dynamic fcBeinviteGroupShips;
@dynamic fcBeinviteGroupInfo;
@dynamic hasAdd;
@end
