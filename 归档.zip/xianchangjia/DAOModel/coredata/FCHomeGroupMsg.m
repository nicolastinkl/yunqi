//
//  FCHomeGroupMsg.m
//  laixin
//
//  Created by apple on 14-1-9.
//  Copyright (c) 2014年 jijia. All rights reserved.
//

#import "FCHomeGroupMsg.h"


@implementation FCHomeGroupMsg

@dynamic gid;
@dynamic gName;
@dynamic gCreatorUid;
@dynamic gBoard;
@dynamic gType;
@dynamic gDate;
@dynamic gbadgeNumber;
@dynamic isMute;
@dynamic gPosition;
@end
