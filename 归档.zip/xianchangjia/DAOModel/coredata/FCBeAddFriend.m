//
//  FCBeAddFriend.m
//  laixin
//
//  Created by apple on 14-1-9.
//  Copyright (c) 2014年 jijia. All rights reserved.
//

#import "FCBeAddFriend.h"
#import "FCUserDescription.h"


@implementation FCBeAddFriend

@dynamic addTime;
@dynamic facebookID;
@dynamic hasAdd;
@dynamic beAddFriendShips;
@dynamic eid;
@end
