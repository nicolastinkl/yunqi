//
//  FCContactsPhone.m
//  laixin
//
//  Created by apple on 14-1-13.
//  Copyright (c) 2014年 jijia. All rights reserved.
//

#import "FCContactsPhone.h"
#import "FCUserDescription.h"


@implementation FCContactsPhone

@dynamic phoneNumber;
@dynamic phoneName;
@dynamic uid;
@dynamic hasLaixin;
@dynamic phoneFCuserDesships;

@end
