//
//  FCFriends.m
//  laixin
//
//  Created by apple on 13-12-27.
//  Copyright (c) 2013年 jijia. All rights reserved.
//

#import "FCFriends.h"
#import "FCUserDescription.h"


@implementation FCFriends

@dynamic friendID;
@dynamic friendRelation;

@end
