//
//  FCAccount.m
//  laixin
//
//  Created by apple on 14-1-14.
//  Copyright (c) 2014年 jijia. All rights reserved.
//

#import "FCAccount.h"
#import "Conversation.h"
#import "FCUserDescription.h"


@implementation FCAccount

@dynamic facebookId;
@dynamic time;
@dynamic sessionid;
@dynamic websocketURL;
@dynamic userJson;
@dynamic conversation;
@dynamic fcindefault;

@end
