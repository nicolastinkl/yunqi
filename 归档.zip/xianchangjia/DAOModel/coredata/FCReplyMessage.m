//
//  FCReplyMessage.m
//  laixin
//
//  Created by apple on 14-1-11.
//  Copyright (c) 2014年 jijia. All rights reserved.
//

#import "FCReplyMessage.h"
#import "ConverReply.h"


@implementation FCReplyMessage

@dynamic postid;
@dynamic replyid;
@dynamic content;
@dynamic time;
@dynamic uid;
@dynamic typeReply;
@dynamic jsonStr;
@dynamic newRelationship;

@end
