//
//  PayPellog.m
//  laixin
//
//  Created by apple on 3/7/14.
//  Copyright (c) 2014 jijia. All rights reserved.
//

#import "PayPellog.h"

@implementation PayPellog

@end

@implementation PayOrderHistorylog

@end

@implementation privatePhotoListInfo


@end