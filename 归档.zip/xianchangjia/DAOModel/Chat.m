//
//  Chat.m
//  ISClone
//
//  Created by Molon on 13-12-2.
//  Copyright (c) 2013年 Molon. All rights reserved.
//

#import "Chat.h"

@implementation Chat

@end
