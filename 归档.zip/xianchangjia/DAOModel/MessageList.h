//
//  MessageList.h
//  ISClone
//
//  Created by Molon on 13-12-9.
//  Copyright (c) 2013年 Molon. All rights reserved.
//

#import "ModelArray.h"

@interface MessageList : ModelArray

- (void)sortWithAscending:(BOOL)asc;

@end
