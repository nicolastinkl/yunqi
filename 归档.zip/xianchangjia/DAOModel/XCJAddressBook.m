//
//  XCJAddressBook.m
//  laixin
//
//  Created by apple on 13-12-20.
//  Copyright (c) 2013年 jijia. All rights reserved.
//

#import "XCJAddressBook.h"

@implementation XCJAddressBook
@synthesize name, email, tel, recordID, sectionNumber;

@end
