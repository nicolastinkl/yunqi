//
//  AFAppDotNetAPIClient6.h
//  AFNetworking iOS Example
//
//  Created by apple on 4/17/14.
//  Copyright (c) 2014 Gowalla. All rights reserved.
//

#import "AFHTTPRequestOperationManager.h"

@interface AFAppDotNetAPIClient6 : AFHTTPRequestOperationManager

+ (AFAppDotNetAPIClient6 *)sharedClient ;
@end
