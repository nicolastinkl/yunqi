
//
//  NSObject_XCJExtendClass.h
//  xianchangjia
//
//  Created by apple on 13-12-17.
//  Copyright (c) 2013年 jijia. All rights reserved.
//

#ifndef XCJExtendClass_h
#define XCJExtendClass_h


#import "GlobalData.h"
#import "DAHttpClient.h"
#import "TalkData.h"
#import "JSONKit.h"
#import "tools.h"
#import "UIImageView+WebCache.h"
#import "UIView+Additon.h"
#import "XCAlbumDefines.h"
