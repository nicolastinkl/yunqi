//
//  MDPostPhotoViewController.h
//  OwnerApp
//
//  Created by tinkl on 22/5/14.
//  Copyright (c) 2014 ___TINKL___. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MDPostPhotoViewController : UIViewController

@property (nonatomic, strong) UIImage *postImage;

@end
