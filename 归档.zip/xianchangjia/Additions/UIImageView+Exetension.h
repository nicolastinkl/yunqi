//
//  UIImageView+Exetension.h
//  xianchangjiaplus
//
//  Created by JIJIA &&&&& apple on 13-3-20.
//
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
@interface UIImageView (UIImageView_Extension)

+ (void) presentModalImage:(NSString *)url;
+ (void) dismissModalImage:(UIButton *)button;

@end
