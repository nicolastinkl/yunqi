//
//  UIAlertViewAddition.h.h
//  XianchangjiaAlbum
//
//  Created by JIJIA &&&&& ljh on 12-12-10.
//  Copyright (c) 2012年 SlowsLab. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UIAlertView (Addition)
    
+(void) showAlertViewWithTitle:(NSString *)title message:(NSString *)message;

+(void) showAlertViewWithMessage:(NSString *)message;

@end
