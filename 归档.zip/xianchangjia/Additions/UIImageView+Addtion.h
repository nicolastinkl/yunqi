//
//  UIImageView+Addtion.h
//  RefreshTable
//
//  Created by Molon on 13-11-13.
//  Copyright (c) 2013年 Molon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (Addtion)

- (void)setImageWithURL:(NSURL *)url placeholderImage:(UIImage*)placeholderImage displayProgress:(BOOL)displayProgress;


@end
