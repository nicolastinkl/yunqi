//
//  NSDataAddition.h
//  XianchangjiaAlbum
//
//  modify from Three20 by Tonny on 6/5/11.
//  Copyright 2012 SlowsLab. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSData (Addition) 

@property (nonatomic, readonly) NSString* md5Hash;

@end
