//
//  UINavigationController+OverBackBtn.h
//  yunqi
//
//  Created by apple on 4/22/14.
//  Copyright (c) 2014 jijia. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationController (OverBackBtn)

-(void) ios6backview;
@end
