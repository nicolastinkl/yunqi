//
//  Copyright (c) 2011 Brian Coyner. All rights reserved.
//

extern void BTSPrintCurrentCTM(CGContextRef context); 
extern void BTSDrawPoint(CGContextRef context, CGPoint point);
extern void BTSDrawCoordinateAxes(CGContextRef context);