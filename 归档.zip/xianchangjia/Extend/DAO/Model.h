//
//  Model.h
//  MolonFrame
//
//  Created by Molon on 13-10-25.
//  Copyright (c) 2013年 Molon. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Model : NSObject

+ (instancetype)turnObject:(NSDictionary*)dict;

@end
