//
//  IQSocialRequestBaseClient6.h
//  yunqi
//
//  Created by apple on 4/17/14.
//  Copyright (c) 2014 jijia. All rights reserved.
//

#import "AFHTTPRequestOperationManager.h"

@interface IQSocialRequestBaseClient6 : AFHTTPRequestOperationManager
+ (IQSocialRequestBaseClient6 *)sharedClient;
@end
